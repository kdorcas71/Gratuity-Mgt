	<style>
	.dropdown:hover .dropdown-menu {
		display: block;
		}
	</style>
		<nav class="navbar navbar-transparent navbar-fixed-top" role="navigation" style="width:10px; height:10px;">
			<div class="container-fluid">
					<ul class="nav navbar-nav">
						<li class="dropdown">
							<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<span class="glyphicon glyphicon-list" ></span>
							</button>
								<ul class="dropdown-menu" role="menu">
									<li><a href="../index.php">HR Department</li>
									<li><a href="../employee/login_emp.php">Employee</a></li>
								</ul>
						</li>
					</ul>
			</div>	
		</nav>