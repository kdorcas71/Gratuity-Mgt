<?php
mysql_select_db('dbhr',mysql_connect('localhost','root',''));
?>