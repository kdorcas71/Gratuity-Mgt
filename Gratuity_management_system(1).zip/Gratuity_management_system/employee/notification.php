<link rel="shortcut icon" href="../hrlogo.png">
<link rel="stylesheet" type="text/css" href="pop.css">
<!-- PIKADAY CALENDAR CODE STARTS HERE-->
<link rel="stylesheet" href="pikaday/css/pikaday.css">
<script src="pikaday/js/moment.js"></script>
<!-- First load pikaday.js and then its jQuery plugin -->
<script src="pikaday/js/pikaday.js"></script>
		<div class="container-fluid">
			<div class="row">
				<?php include ('menu.php'); ?>
			</div>
		</div>
<div class="container-fluid">


	<div class="row" style="margin-top:20px">
		<div class="col-xs-9 col-md-offset-3">
			<div class="row">
				<div class="col-md-12">
					<div class="page-header">
						<h1>EXIT QUESTIONAIRE</h1>
					</div>
				</div>
			</div>
<div class="container-fluid">
	<div class = "row">
		<div class="panel panel-default">
			<div class="panel-body">
					<form enctype="multipart/form-data" method="post" class="form-horizontal">
						<fieldset>
							<div class = "col-md-9 col-md-offset-2">
								<h3>Exit Interview</h3>
							</div>
							
							<!-- Text input-->
							<div class="form-group">
								<label class="col-md-2 control-label" for="id_emp">Employee ID</label>
							  <div class="col-md-2">
							  <input id="id_emp" name="id_emp" type="text" class="form-control input-md" value="<?php echo $id;?>" readonly>
							
							  </div>
							
							</div>

							<!-- Text input-->
							<div class="form-group" >
							  <label class="col-md-2 control-label" for="emp_fname">Full Name</label>  
							  <div class="col-md-3">
							  <input id="emp_fname" name="emp_fname" type="text" class="form-control input-md" value="<?php echo $FirstName;?>" readonly>
							  </div>
								<label class="col-md- control-label" for="emp_mname"></label>  
							  <div class="col-md-3">
							  <input id="emp_mname" name="emp_mname" type="text" class="form-control input-md" value="<?php echo $MiddleName;?>" readonly>
							  </div>
								<label class="col-md- control-label" for="emp_lname"></label>
							  <div class="col-md-3">
								<input id="emp_lname" name="emp_lname" type="text" class="form-control input-md" value="<?php echo $LastName;?>" readonly>
							  </div>
							  </div>
							  <!-- Select Basic -->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="month">Start Date With Organization </label>
							  <div class="col-md-2">
							   <input id="startDate" name="startDate" type="text" class="form-control input-md" value="<?php echo $startDate;?>" readonly>
								
							  </div>
							 
							</div>
							<div class="form-group">
							  <label class="col-md-2 control-label" for="month">End Date</label>
							  <div class="col-md-2">
							  <input type="text" name="enddate" id="enddate" class="form-control"/>
								
							  </div>
							
							  <div class="col-md-2">
							    
							  </div>
							
							  <div class="col-md-2">
								
					
							  </div>
							  
							</div>
							<div class="form-group">
							  <label class="col-md-7 control-label" for="comment1">Please describe the primary reason(s) you are leaving your current position.</label>
							  <div class="col-md-4">                     
								<textarea class="form-control" id="comment1" name="comment1" placeholder="comment"></textarea>
							  </div>
							</div>
							<div class="form-group">
							  <label class="col-md-7 control-label" for="ecomment2">Was your career path and future with our organization made clear to you?</label>
							  <div class="col-md-4">                     
								<textarea class="form-control" id="comment2" name="comment2" placeholder="comment"></textarea>
							  </div>
							  </div>
							  <div class="form-group">
							  <label class="col-md-7 control-label" for="comment3">Do you have any other comments or suggestions?</label>
							  <div class="col-md-4">                     
								<textarea class="form-control" id="comment3" name="comment3" placeholder="comment"></textarea>
							  </div>
							  <!-- Text input-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="sumitedby"></label>  
							  <div class="col-md-3">
							  <input id="submitedby" name="submitedby" type="hidden" class="form-control input-md" value="<?php echo $id;?>" readonly>
								
							  </div>
							</div>

							  <!-- Button (Double) -->
							<div class="form-group">
							  <label class="col-md-3 control-label" for="submit"></label>
							  <div class="col-md-4">
								<button id="submit" name="submit" class="btn btn-primary">Submit</button>
								<a href = "index.php"><input type = "button" value = "Cancel" class="btn btn-default"></a>
								</fieldset>
					</form>
							  </div>
							</div>
	<div class="container-fluid">
		<div class = "col-md-12">
			<div style="margin-top:100px;" class="text-center">
				
			</div>
		</div>
	</div>
    <?php	
	if (isset($_POST['submit'])){
		
		if (($_POST['emp_fname'] == '')or($_POST['emp_lname'] == '')or($_POST['emp_mname'] == '')or ($_POST['enddate'] == '')
		
		or($_POST['comment1'] == '')
		or($_POST['comment2'] == '')or($_POST['comment3'] == '')or($_POST['submitedby'] == ''))
		{
		
			echo "You must fill those fields";
		}	
	else{ 
		
		$a = addslashes("$_POST[id_emp]");
		$b = addslashes("$_POST[emp_fname]");
		$c = addslashes("$_POST[emp_lname]");
		$d = addslashes("$_POST[emp_mname]");
		//$e = addslashes("".$_POST['year']."-".$_POST['month']."-".$_POST['day']."");
		$f = addslashes("$_POST[enddate]");
		//$g = addslashes("$_POST[length_service]");
		$h = addslashes("$_POST[comment1]");
		$i = addslashes("$_POST[comment2]");
		$j = addslashes("$_POST[comment3]");
		$k = addslashes("$_POST[submitedby]");

//code for sending an acknowledgement email to the employee
require('phpmailer/class.phpmailer.php');		
		
//code for calculating months worked by subtracting the startdate from the enddate
$sdate = strtotime($startDate);
$edate = strtotime($f);

$year1 = date('Y', $sdate);
$year2 = date('Y', $edate);

$month1 = date('m', $sdate);
$month2 = date('m', $edate);

$lengthofservice = (($year2 - $year1) * 12) + ($month2 - $month1);

if($lengthofservice<12)
{

$mail3 = new PHPMailer();
$mail3->IsSMTP();
$mail3->Host = "smtp.gmail.com";
$mail3->SMTPAuth = true;
$mail3->Username = 'dkagoya171@gmail.com';
$mail3->Password = 'ndikwani71';

	$mail3->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only

	$mail3->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail

	$mail3->Port = 465; 

$mail3->From="dkagoya171@gmail.com";
$mail3->FromName="GRATUITY MIS";
$mail3->Sender="dkagoya171@gmail.com";
$mail3->AddReplyTo("dkagoya171@gmail.com", "JOB EXIT CONFIRMATION");

if($email !=" ")
{

$mail3->AddAddress($email);
$emailaddresses= $email ;
}

$mail3->Subject = "JOB EXIT CONFIRMATION";
$mail3->IsHTML(false);

$mail3->Body = "Dear"." ".$FirstName."".".thank you for submitting your Job exit request, the Human Resource officer will respond you soon. However,you do not qualify for gratuity because you have served for less than a year";

$mail3->WordWrap   = 65; // set word wrap

if(!$mail3->Send()) 
{
  echo "Mailer Error: " . $mail3->ErrorInfo;
} 
else 
{
  
   $stt="Confirmation has been sent to your email";
  ?>
  
  <div class="alert alert-success" align="center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php  echo $stt; ?>
</div>
<?php
}
?>

<?php

//Code for sending email alert to the human resource officer
$retrieve2 = mysql_query("SELECT * FROM employee WHERE emp_pos='Human Resource'");

while ($row=mysql_fetch_assoc($retrieve2)) 
 { 
$id2 =$row['id_emp'];
$firstName2 = $row['emp_fname'];
$lastNam2 = $row['emp_lname'];
$MNam2 = $row['emp_mname'];
$email2 = $row['email'];
}

$mail4 = new PHPMailer();
$mail4->IsSMTP();
$mail4->Host = "smtp.gmail.com";
$mail4->SMTPAuth = true;
$mail4->Username = 'dkagoya171@gmail.com';
$mail4->Password = 'ndikwani71';

	$mail4->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only

	$mail4->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail

	$mail4->Port = 465; 

$mail4->From="dkagoya171@gmail.com";
$mail4->FromName="GRATUITY MIS";
$mail4->Sender="dkagoya171@gmail.com";
$mail4->AddReplyTo("dkagoya171@gmail.com", "STAFF LEAVING THE UNIVERSITY");

if($email2 !=" ")
{

$mail4->AddAddress($email2);
$emailaddresses= $email2 ;
}

$mail4->Subject = "STAFF LEAVING THE UNIVERSITY";
$mail4->IsHTML(false);

$mail4->Body = "Dear"." ".$firstName2." "."".".a staff wants to quit working for the university by". " "."$f"." ". ". However, they do not qualify for gratuity because they have served for less than a year";

$mail4->WordWrap   = 65; // set word wrap

if(!$mail4->Send()) 
{
  echo "Mailer Error: " . $mail4->ErrorInfo;
} 
else {
  
   $stt="and also to the Human Resource Officer";
  ?>
  
  <div class="alert alert-success" align="center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php  echo $stt; ?>
</div>
<?php
}

?>


<?php

}
else
{



$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->Username = 'dkagoya171@gmail.com';
$mail->Password = 'ndikwani71';

	$mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only

	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail

	$mail->Port = 465; 

$mail->From="dkagoya171@gmail.com";
$mail->FromName="GRATUITY MIS";
$mail->Sender="dkagoya171@gmail.com";
$mail->AddReplyTo("dkagoya171@gmail.com", "JOB EXIT CONFIRMATION");

if($email !=" ")
{

$mail->AddAddress($email);
$emailaddresses= $email ;
}

$mail->Subject = "JOB EXIT CONFIRMATION";
$mail->IsHTML(false);

$mail->Body = "Dear"." ".$FirstName."".".thank you for submitting your Job exit request, the Human Resource officer will respond you soon.";

$mail->WordWrap   = 65; // set word wrap

if(!$mail->Send()) 
{
  echo "Mailer Error: " . $mail->ErrorInfo;
} 
else {
  
   $stt="Confirmation has been sent to your email";
  ?>
  
  <div class="alert alert-success" align="center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php  echo $stt; ?>
</div>
<?php
}
?>


<?php
//Code for sending email alert to the human resource officer
$retrieve2 = mysql_query("SELECT * FROM employee WHERE emp_pos='Human Resource'");

while ($row=mysql_fetch_assoc($retrieve2)) 
 { 
$id2 =$row['id_emp'];
$firstName2 = $row['emp_fname'];
$lastNam2 = $row['emp_lname'];
$MNam2 = $row['emp_mname'];
$email2 = $row['email'];
}

$mail2 = new PHPMailer();
$mail2->IsSMTP();
$mail2->Host = "smtp.gmail.com";
$mail2->SMTPAuth = true;
$mail2->Username = 'dkagoya171@gmail.com';
$mail2->Password = 'ndikwani71';

	$mail2->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only

	$mail2->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail

	$mail2->Port = 465; 

$mail2->From="dkagoya171@gmail.com";
$mail2->FromName="GRATUITY MIS";
$mail2->Sender="dkagoya171@gmail.com";
$mail2->AddReplyTo("dkagoya171@gmail.com", "STAFF LEAVING THE UNIVERSITY");

if($email2 !=" ")
{

$mail2->AddAddress($email2);
$emailaddresses= $email2 ;
}

$mail2->Subject = "STAFF LEAVING THE UNIVERSITY";
$mail2->IsHTML(false);

$mail2->Body = "Dear"." ".$firstName2." "."".".a staff wants to quit working for the university by". " "."$f"." ". "Please check out for the details in the system and calculate the respective gratuity";

$mail2->WordWrap   = 65; // set word wrap

if(!$mail2->Send()) 
{
  echo "Mailer Error: " . $mail2->ErrorInfo;
} 
else {
  
   $stt="and also to the Human Resource Officer";
  ?>
  
  <div class="alert alert-success" align="center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php  echo $stt; ?>
</div>
<?php
}

}
?>
<?php


		//insert into database
		$sql = "INSERT INTO notification
					(`id_emp`,`start_date`,`end_date`,`length_service`,`comment1`,`comment2`,`comment3`,`submitedby`)
						values('$a','$startDate','$f','$lengthofservice','$h','$i','$j','$k')";
		$qry = mysql_query($sql);
			if ($qry){
				echo '<div style="position:absolute; left:450px; top:200px; width: 450px">
								<div class="alert alert-success">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">
										�</button>
								   <span class="glyphicon glyphicon-ok"></span> <strong>Done!</strong>
									<hr class="message-inner-separator">
									<p><strong>Success!</strong> Notification successfully sent!
									&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
									<a href="home.php"><button type="button" class="btn btn-success">Continue</button></a>
									</p>
								</div>
							</div>';
							//$diff=date_diff($e,$f);
                           // echo $diff->format("%R%y years");
							 
							
							 //echo $years;
							 
					exit();
					
				}
				
			else {
				echo "not posted!";
				}
		}
	}
?>
    
    
		<?php
			include ('footer.php');
		?>
<script>
	var enddate = new Pikaday(
    {
	     format: 'YYYY-MM-DD',
        field: document.getElementById('enddate'),
		minDate: new Date(),
	
		
        
    });
	
	
	
	
</script>