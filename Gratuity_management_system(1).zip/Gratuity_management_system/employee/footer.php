		
			<link href="../bootstrap/css/sticky-footer.css" rel="stylesheet">
			<footer class="footer">
			  <div class="container">
				<p class="text-center">Uganda Matyrs University 2017</p>
			  </div>
			</footer>
	</div>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>