<!--connection sa database-->
<?php include('../conn.php'); ?>
<!--end of connection-->
<?php
include('session.php');
mysql_query("update user_log set logout_Date = NOW() where id = '$session_id' ")or die(mysql_error());

session_start();
session_destroy();

if( isset($_SESSION['LAST_REQUEST']) &&
    (time() - $_SESSION['LAST_REQUEST'] > 60) ) {
    session_unset();
    session_destroy();
    header('/login?sessionExpired');
    exit();
}
 
$_SESSION['LAST_REQUEST'] = time();
header('location:../index.php');
?>
