<link rel="shortcut icon" href="../hrlogo.png">
<link rel="stylesheet" type="text/css" href="pop.css">
		<div class="container-fluid">
			<div class="row">
				<?php include ('menu.php'); ?>
			</div>
		</div>
<div class="container-fluid">
	<div class="row" style="margin-top:20px">
		<div class="col-xs-9 col-md-offset-3">
			<div class="col-xs-4">
						
				<div class="offer offer-info">
					<div class="shape">
						<div class="shape-text">
														
						</div>
					</div>
					<div class="offer-content">
					  <p>
							
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	<div class="container-fluid">
		<div class = "col-md-12">
			<div style="margin-top:100px;" class="text-center">
				<p style ="font-family:Georgia; font-size:40px;">Gratuity Management System</p>
				<div data-eds-entry-animation="fadeInLeft" data-eds-entry-delay="0" data-eds-entry-duration="1" data-eds-entry-timing="ease-out" data-eds-exit-animation="" data-eds-exit-delay="" data-eds-exit-duration="" data-eds-exit-timing="" data-eds-repeat-count="1" data-eds-keep="yes" data-eds-animate-on="load" data-eds-scroll-offset="">
                  <h3><strong>Goodbye Spreadsheet Error Risks</strong></h3>
				  <h3><strong>Hello Simple, Transparent, &amp; Automated Gratuity Management System </strong></h3>
			  </div>
				<p style ="font-family:Georgia; font-size:60px;">&nbsp;</p>
			</div>
		</div>
	</div>
		<?php
			include ('footer.php');
		?>