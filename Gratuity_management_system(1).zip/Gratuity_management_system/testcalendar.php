


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title></title>
<!-- PIKADAY CALENDAR CODE STARTS HERE-->
<link rel="stylesheet" href="pikaday/css/pikaday.css">
<script src="pikaday/js/moment.js"></script>
<!-- First load pikaday.js and then its jQuery plugin -->
<script src="pikaday/js/pikaday.js"></script>



<!-- BOOTSTRAP CODE STARTS HERE-->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="DataTables/media/jquery-1.12.1.min.js"> </script>
<link rel="stylesheet" type="text/css" href="bootstrap-3.3.6-dist/css/bootstrap.min.css"/>
<script src="bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
<script src="DataTables/media/js/jquery.dataTables.min.js"> </script>


<!-- code for jquery live validations-->
<script src='jqueryplugin/jquery.js'></script>
<script src='jqueryplugin/jquery.validate.min.js'></script>
<!-- LINK TO MY JQUERY CUSTOM DEFINED FUNCTIONS-->






</head>

<body>
 
<form  method="post" action="" id="dats" name="dats">

       <table width="605" height="118" >
        
         <tr>
           <td>&nbsp;</td>
           <td width="35%"><span class="mandatory" style="color:#FF0000">*</span>Payment Date </td>
            <td width="56%"><input type="text" name="paymentdate" id="paymentdate" class="form-control"/> </td>
           <td>&nbsp;</td>
         </tr>
        
         
         <tr>
           <td>&nbsp;</td>
           <td width="35%"><span class="mandatory" style="color:#FF0000">*</span>Payment Expiration Date </td>
            <td width="56%"><input type="text" name="ValidUntilDate" id="ValidUntilDate"  class="form-control" /></td>
           <td>&nbsp;</td>
         </tr>

      

    </tbody>
  </table>
</form>

</body>
</html>
<script>
	
	var ValidUntilDate = new Pikaday(
    {
	    format: 'YYYY-MM-DD',
        field: document.getElementById('ValidUntilDate'),
		minDate: new Date(),
		
        
    });
	
	var paymentdate = new Pikaday(
    {
	    format: 'MMMM  DD , YYYY',
        field: document.getElementById('paymentdate'),
		minDate: moment().subtract(1, 'years').toDate(),
	
		
        
    });
	
</script>