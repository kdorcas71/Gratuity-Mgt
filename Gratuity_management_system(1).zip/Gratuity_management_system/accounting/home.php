<link rel="shortcut icon" href="../hrlogo.png">		
		<div class="container-fluid">
			<div class="row">
				<?php include ('menu.php'); ?>
			</div>
		</div>
	<div class="container-fluid">
		<div class = "col-md-12">
			<div style="margin-top:150px;" class="text-center">
				<p style ="font-family:Georgia; font-size:60px;">Human Resource Support System</p>
			</div>
		</div>
	</div>
		<?php
			include ('footer.php');
		?>