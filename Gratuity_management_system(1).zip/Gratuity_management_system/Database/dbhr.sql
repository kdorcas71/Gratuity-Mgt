-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 05, 2017 at 07:47 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbhr`
--

-- --------------------------------------------------------

--
-- Table structure for table `alert`
--

CREATE TABLE IF NOT EXISTS `alert` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `id_emp` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `enddate` date NOT NULL,
  `sentby` varchar(128) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `alert`
--

INSERT INTO `alert` (`id`, `id_emp`, `reason`, `enddate`, `sentby`, `datecreated`) VALUES
(1, '568', 'Testing the employee alert', '0000-00-00', ' dorcus Kagoya ', '0000-00-00 00:00:00'),
(2, '12345', 'You will be terminated soon', '0000-00-00', ' dorcus Kagoya ', '0000-00-00 00:00:00'),
(3, 'c11-2507', 'Is the email alert working?', '0000-00-00', ' dorcus Kagoya ', '0000-00-00 00:00:00'),
(4, 'NDU405', 'okuze', '2017-05-31', ' dorcus Kagoya ', '2017-05-19 04:52:12'),
(5, 'NDU405', 'Non perfomance', '2017-08-31', ' dorcus Kagoya ', '2017-05-19 04:55:42');

-- --------------------------------------------------------

--
-- Table structure for table `basic_pay`
--

CREATE TABLE IF NOT EXISTS `basic_pay` (
  `id_basic` mediumint(128) NOT NULL AUTO_INCREMENT,
  `sal_scale` varchar(128) NOT NULL,
  `basic_pay` int(128) NOT NULL,
  PRIMARY KEY (`id_basic`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `basic_pay`
--

INSERT INTO `basic_pay` (`id_basic`, `sal_scale`, `basic_pay`) VALUES
(1, 'UMU 1', 4000000),
(2, 'UMU 2', 2800000),
(3, 'UMU 3', 1000000),
(4, 'UMU 4', 800000),
(6, 'UMU 6', 500000),
(7, 'UMU 7', 450000),
(8, 'UMU 8', 300000),
(9, 'UMU 9', 300000),
(10, 'UMU 10', 250000),
(11, 'UMU 5', 750000);

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE IF NOT EXISTS `contract` (
  `id_cont` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `cont_date` date NOT NULL,
  `cont_stat` int(2) NOT NULL,
  PRIMARY KEY (`id_cont`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contract`
--

INSERT INTO `contract` (`id_cont`, `emp_id`, `start_date`, `end_date`, `cont_date`, `cont_stat`) VALUES
(1, 21, '2015-02-09', '2015-03-09', '2015-02-09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dean`
--

CREATE TABLE IF NOT EXISTS `dean` (
  `id_dean` int(11) NOT NULL AUTO_INCREMENT,
  `id_dept` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `department` varchar(128) NOT NULL,
  PRIMARY KEY (`id_dean`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `dean`
--

INSERT INTO `dean` (`id_dean`, `id_dept`, `emp_id`, `department`) VALUES
(1, 1, 10, 'SECS'),
(2, 5, 8, 'Basic ED');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `id_dept` int(11) NOT NULL,
  `depart_name` varchar(128) NOT NULL,
  `emp_id` varchar(11) NOT NULL,
  PRIMARY KEY (`id_dept`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id_dept`, `depart_name`, `emp_id`) VALUES
(1, 'SECS', '4'),
(2, 'Human Resource', '21'),
(3, 'SMEAS', '10'),
(4, 'SBA', '22'),
(5, 'Basic ED', '9');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `emp_id` int(100) NOT NULL AUTO_INCREMENT,
  `id_emp` varchar(128) NOT NULL,
  `emp_fname` varchar(128) NOT NULL,
  `emp_lname` varchar(128) NOT NULL,
  `emp_mname` varchar(128) NOT NULL,
  `emp_bday` varchar(128) NOT NULL,
  `emp_gen` varchar(128) NOT NULL,
  `emp_add` varchar(128) NOT NULL,
  `emp_stat` varchar(128) NOT NULL,
  `emp_cont` varchar(11) NOT NULL,
  `nssf` int(10) NOT NULL,
  `tin` varchar(13) NOT NULL,
  `email` varchar(128) NOT NULL,
  `emp_pos` varchar(128) NOT NULL,
  `id_pos` int(11) NOT NULL,
  `id_dept` int(11) NOT NULL,
  `addedby` varchar(128) NOT NULL,
  `emp_date` date NOT NULL,
  `stat` int(2) NOT NULL,
  `emp_start` date NOT NULL,
  `id_scale` varchar(8) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `id_emp`, `emp_fname`, `emp_lname`, `emp_mname`, `emp_bday`, `emp_gen`, `emp_add`, `emp_stat`, `emp_cont`, `nssf`, `tin`, `email`, `emp_pos`, `id_pos`, `id_dept`, `addedby`, `emp_date`, `stat`, `emp_start`, `id_scale`) VALUES
(4, '123', 'Franklin', 'Castro', 'Rojo', 'April-7-1994', 'Female', 'San Jose', 'Married', '2147483647', 1234567890, '123456789012b', 'dtsnbazzeketa7@gmail.com', 'Program Head', 1, 1, ' Franklin Castro ', '2015-01-19', 1, '2012-10-01', '2'),
(8, '110', 'Dorcas', 'Kagoya', 'lachica', 'July-19-1972', 'Male', 'kabankalan city', 'Widow', '09873535343', 94394592, '028-429-4829', 'kdorcas71@gmail.com', 'Human Resource', 1, 5, ' Franklin Castro', '2015-02-08', 1, '0000-00-00', '8'),
(9, 'C11-0022', 'Kristian Rey', 'Tondo', 'Bandolos ', 'December-12-1993', 'Male', 'Brgy. Tabu, Ilog, Negros Occidental', 'Single', '09498583177', 0, '212112112121', 'Kabankalan City', 'Staff', 1, 5, ' Franklin Castro', '2015-02-08', 2, '0000-00-00', '9'),
(10, '1234', 'vincent', 'gallendo', 'gwapo', 'February-1-1971', 'Male', 'd makita street', 'Widower', '09878676', 87866700, '08970-786', 'wtw@fkjhs', 'Teaching Personnel', 2, 1, ' Franklin Castro', '2015-02-08', 1, '0000-00-00', '1'),
(11, '23', 'hdu', 'abi', 'nanau', 'March-7-1972', 'Male', 'd makita', 'Married', '09079666', 66699, '08080-=90', 'dashh', 'Secretary', 2, 1, ' Franklin Castro', '2015-02-08', 2, '0000-00-00', '4'),
(21, 'c11-2507', 'Rosalyn', 'Castro', 'Apolonio', 'September-25-1993', 'Female', 'Tabugon', 'Married', '09219590720', 1234567890, '123456789012b', 'frankzkhie@gmail.com', 'Program Head', 2, 2, ' Franklin Castro', '2015-02-08', 1, '0000-00-00', '5'),
(23, '12345', 'john', 'kiggundu', 'baptist', 'March-7-1982', 'Male', 'bwaise', 'Widow', '0775051275', 7684231, '89987', 'kuggundu46@gmail.com', 'Non Teaching Staff', 1, 2, ' Denis Luwaga ', '2017-03-25', 1, '1990-01-20', '1'),
(24, 'ucu675', 'gloria', 'nakakoole', 'kiyemba', 'January-18-1987', 'Female', 'mukono', 'Single', '0774105376', 10, '9876', 'gnakakole@ucu.ac.ug', 'Administrative', 2, 1, ' Denis Luwaga ', '0000-00-00', 1, '2012-03-27', '7'),
(25, 'umu929', 'Ovious', 'Alikiriza', 'Cathy', '1986-02-12', 'Female', 'Makindye', 'Single', '0772387578', 8, '34567', 'oviousndyaguma@gmail.com', 'Administrative', 2, 2, ' Denis Luwaga ', '0000-00-00', 1, '0000-00-00', '7'),
(26, 'umu234', 'stephen', 'barinda', 'byaruhanga', '1971-02-8', 'Male', 'mukono', 'Married', '0782820479', 4, '98765432', 'sbarinda@umu.ac.ug', 'Teaching Personnel', 1, 2, ' Denis Luwaga ', '0000-00-00', 1, '0000-00-00', '5'),
(27, '56', 'Bosco', 'Kifulugunyu', 'Remmy', '1970-01-2', 'Male', '4 Mukono', 'Single', '0774105376', 2, '67543234', 'kdorcas71@gmail.com', 'Administrative', 1, 1, ' Denis Luwaga ', '0000-00-00', 1, '2000-02-10', '1'),
(28, '$a', '$b', '$c', '$d', '$e', '$g', '$h', '$i', '$j', 0, '$o', '$u', '$k', 0, 0, '$l', '0000-00-00', 1, '0000-00-00', '6'),
(29, '567', 'Robert', 'Kisseka', 'William', '1972-01-2', 'Male', '4, Muyenga', 'Single', '0779205097', 10, '6788', 'kdorcas71@gmail.com', 'Administrative', 1, 1, ' Denis Luwaga ', '2017-03-30', 1, '0000-00-00', '2003-Jan'),
(30, '568', 'Graham', 'Lubega', 'Bell', '1973-01-4', 'Male', '4 Tufnel Drive', 'Single', '0774105376', 2, '67543234', 'kdorcas71@gmail.com', 'Administrative', 1, 1, ' Denis Luwaga ', '2017-03-30', 1, '0000-00-00', '2'),
(31, 'ucu675', 'Bosco', 'lulo', 'ndikwani', '1986-02-19', 'Female', 'bweyogerere', 'Single', '0779205097', 10, '0987654', 'kuggundu46@gmail.com', 'Teaching Personnel', 1, 3, ' Denis Luwaga ', '2017-03-30', 1, '2005-06-18', '10'),
(32, 'umu789', 'ovious', 'alikiriza', 'ndyaguma', 'January-01-1987', 'Female', 'makindye', 'Single', '0700335751', 2147483647, '23456787654', 'oviousndyaguma@gmail.com', 'Teaching Personnel', 1, 1, ' dorcus Kagoya ', '2017-04-06', 1, '1999-08-18', '6'),
(33, 'umu567', 'edwin', 'byarugaba', 'amooti', '1986-11-31', 'Male', 'bugujju', 'Single', '0789405678', 9, '9344444444456', 'byarugabaedwin@gmail.com', 'Non Teaching Staff', 1, 4, ' dorcus Kagoya ', '2017-04-07', 1, '2014-11-19', '9'),
(34, 'w12', 'test', 'testing', 'none', '1982-01-18', 'Male', 'Ndejje', 'Single', '+2567788991', 3, '222222222', 'test@gmail.com', 'Administrative', 1, 2, ' dorcus Kagoya ', '2017-04-15', 1, '2000-04-16', '3'),
(35, 'umu607', 'hilda', 'katushabe', 'kemigisha', '1978-01-12', 'Female', 'masanafu', 'Married', '0779205097', 9, '79347321', 'dluwaga@umu.ac.ug', 'Administrative', 2, 1, ' dorcus Kagoya ', '2017-04-22', 1, '2017-03-01', '9'),
(36, 'NDU405', 'Betty', 'Namugabo', 'Liz', '1993-08-02', 'Female', 'luwero', 'Single', '0794770816', 10, '98765432', 'dkagoya@ucu.ac.ug', 'Teaching Personnel', 3, 5, ' dorcus Kagoya ', '2017-04-29', 1, '1987-11-19', '10');

-- --------------------------------------------------------

--
-- Table structure for table `gratuity`
--

CREATE TABLE IF NOT EXISTS `gratuity` (
  `emp_id` int(128) NOT NULL AUTO_INCREMENT,
  `id_emp` varchar(128) NOT NULL,
  `length_service` int(128) NOT NULL,
  `sal_scale` varchar(128) NOT NULL,
  `basic_pay` int(128) NOT NULL,
  `totalgratuity` float NOT NULL,
  `date_calculated` date NOT NULL,
  `submitedby` int(20) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `gratuity`
--

INSERT INTO `gratuity` (`emp_id`, `id_emp`, `length_service`, `sal_scale`, `basic_pay`, `totalgratuity`, `date_calculated`, `submitedby`) VALUES
(4, '12345', 12, '1', 4000000, 4800000, '2017-04-16', 110),
(5, 'umu607', 193, '9', 300000, 5790000, '2017-04-22', 110),
(6, 'NDU405', 357, '10', 250000, 8925000, '2017-05-19', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ldays`
--

CREATE TABLE IF NOT EXISTS `ldays` (
  `id_pos` mediumint(10) NOT NULL AUTO_INCREMENT,
  `pos_stat` varchar(20) NOT NULL,
  `adays` int(10) NOT NULL,
  PRIMARY KEY (`id_pos`),
  KEY `posid` (`pos_stat`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ldays`
--

INSERT INTO `ldays` (`id_pos`, `pos_stat`, `adays`) VALUES
(1, 'Permanent', 15),
(2, 'Contract', 15),
(3, 'Part Time', 15);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `emp_id` int(100) NOT NULL AUTO_INCREMENT,
  `id_emp` varchar(128) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `length_service` int(128) NOT NULL,
  `comment1` varchar(128) NOT NULL,
  `comment2` varchar(128) NOT NULL,
  `comment3` varchar(128) NOT NULL,
  `submitedby` int(20) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`emp_id`, `id_emp`, `start_date`, `end_date`, `length_service`, `comment1`, `comment2`, `comment3`, `submitedby`) VALUES
(35, '12345', '1986-01-02', '2012-05-03', 12, 'sss', 'sss', 'ss', 0),
(36, '12345', '1982-01-07', '2016-09-14', 12, 'wwww', 'wwww', 'wwww', 0),
(37, '12345', '2000-01-01', '2017-01-01', 12, 'aaaa', 'aaaa', 'aaa', 0),
(38, '12345', '2000-01-01', '2017-02-04', 10, 'aaaa', 'aaaa', 'aaaa', 0),
(49, ' 123 ', '2012-10-01', '2016-05-17', 43, 'less pay', 'No', 'i want my gratuity', 0),
(50, ' 12345 ', '1990-01-20', '2017-01-03', 324, 'less pay', 'no', 'no', 0),
(51, ' umu789 ', '1999-08-18', '2016-12-31', 208, 'new job', 'no', 'no', 0),
(52, ' umu567 ', '2014-11-19', '2016-12-31', 25, 'new job', 'no', 'no', 0),
(53, ' umu567 ', '2014-11-19', '2016-12-31', 25, 'new job', 'no', 'no', 0),
(54, 'umu607', '2000-11-01', '2016-12-31', 193, 'new offer', 'no it was not', 'no', 0),
(55, 'umu607', '2000-11-01', '1988-02-17', -153, 'npp', 'jhj', 'no', 0),
(56, 'NDU405', '1987-11-19', '2017-08-31', 357, 'Got a new offer', 'no it was not clear', 'NO', 0),
(57, 'umu607', '2017-03-01', '2017-05-31', 2, 'new offer', 'no it was not clear', 'No', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sal_scale`
--

CREATE TABLE IF NOT EXISTS `sal_scale` (
  `id_scale` mediumint(10) NOT NULL AUTO_INCREMENT,
  `sal_scale` varchar(20) NOT NULL,
  PRIMARY KEY (`id_scale`),
  KEY `posid` (`sal_scale`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `sal_scale`
--

INSERT INTO `sal_scale` (`id_scale`, `sal_scale`) VALUES
(1, 'UMU 1'),
(10, 'UMU 10'),
(2, 'UMU 2'),
(3, 'UMU 3'),
(4, 'UMU 4'),
(5, 'UMU 5'),
(6, 'UMU 6'),
(7, 'UMU 7'),
(8, 'UMU 8'),
(9, 'UMU 9');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `lastname`, `status`) VALUES
(3, 'kagoya', '5f93f983524def3dca464469d2cf9f3e', 'dorcas', 'Kagoya', 'administrator'),
(4, 'namugabo', 'c1c15cfa7ab3e093ef4490e673471114', 'betty', 'namugabo', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE IF NOT EXISTS `user_log` (
  `user_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `login_date` varchar(30) NOT NULL,
  `logout_date` varchar(30) NOT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`user_log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=287 ;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`user_log_id`, `username`, `login_date`, `logout_date`, `id`) VALUES
(71, 'executive', '2015-02-07 19:18:23', '2015-02-22 23:28:17', 3),
(72, 'admin', '2015-02-07 19:55:10', '2017-04-04 18:16:08', 1),
(73, 'admin', '2015-02-07 22:02:33', '2017-04-04 18:16:08', 1),
(74, 'admin', '2015-02-07 22:05:45', '2017-04-04 18:16:08', 1),
(75, 'admin', '2015-02-08 10:53:59', '2017-04-04 18:16:08', 1),
(76, 'executive', '2015-02-08 11:01:54', '2015-02-22 23:28:17', 3),
(77, 'admin', '2015-02-08 11:11:25', '2017-04-04 18:16:08', 1),
(78, 'admin', '2015-02-08 12:03:57', '2017-04-04 18:16:08', 1),
(79, 'admin', '2015-02-08 13:54:48', '2017-04-04 18:16:08', 1),
(80, 'admin', '2015-02-08 16:25:12', '2017-04-04 18:16:08', 1),
(81, 'acc', '2015-02-08 17:25:28', '2016-07-09 10:54:42', 4),
(82, 'finance', '2015-02-08 18:21:19', '2017-04-07 12:12:45', 5),
(83, 'acc', '2015-02-08 18:26:28', '2016-07-09 10:54:42', 4),
(84, 'admin', '2015-02-08 18:33:39', '2017-04-04 18:16:08', 1),
(85, 'finance', '2015-02-08 18:37:01', '2017-04-07 12:12:45', 5),
(86, 'acc', '2015-02-08 18:37:49', '2016-07-09 10:54:42', 4),
(87, 'finance', '2015-02-08 18:46:12', '2017-04-07 12:12:45', 5),
(88, 'acad', '2015-02-08 19:00:16', '2016-07-09 11:09:57', 6),
(89, 'acad', '2015-02-08 19:25:56', '2016-07-09 11:09:57', 6),
(90, 'executive', '2015-02-08 20:10:59', '2015-02-22 23:28:17', 3),
(91, 'operation', '2015-02-08 20:17:33', '2016-07-09 11:10:54', 2),
(92, 'operation', '2015-02-08 22:23:17', '2016-07-09 11:10:54', 2),
(93, 'admin', '2015-02-09 10:21:24', '2017-04-04 18:16:08', 1),
(94, 'executive', '2015-02-09 10:37:05', '2015-02-22 23:28:17', 3),
(95, 'operation', '2015-02-09 10:45:57', '2016-07-09 11:10:54', 2),
(96, 'executive', '2015-02-09 10:52:33', '2015-02-22 23:28:17', 3),
(97, 'executive', '2015-02-09 10:54:51', '2015-02-22 23:28:17', 3),
(98, 'admin', '2015-02-09 14:30:04', '2017-04-04 18:16:08', 1),
(99, 'admin', '2015-02-09 22:05:25', '2017-04-04 18:16:08', 1),
(100, 'admin', '2015-02-10 03:58:17', '2017-04-04 18:16:08', 1),
(101, 'operation', '2015-02-10 04:00:20', '2016-07-09 11:10:54', 2),
(102, 'executive', '2015-02-10 04:00:54', '2015-02-22 23:28:17', 3),
(103, 'admin', '2015-02-10 08:57:42', '2017-04-04 18:16:08', 1),
(104, 'admin', '2015-02-10 09:07:24', '2017-04-04 18:16:08', 1),
(105, 'admin', '2015-02-10 17:54:15', '2017-04-04 18:16:08', 1),
(106, 'admin', '2015-02-11 08:38:22', '2017-04-04 18:16:08', 1),
(107, 'executive', '2015-02-11 09:34:29', '2015-02-22 23:28:17', 3),
(108, 'operation', '2015-02-11 12:15:58', '2016-07-09 11:10:54', 2),
(109, 'executive', '2015-02-11 12:26:29', '2015-02-22 23:28:17', 3),
(110, 'admin', '2015-02-11 12:38:08', '2017-04-04 18:16:08', 1),
(111, 'admin', '2015-02-12 14:20:27', '2017-04-04 18:16:08', 1),
(112, 'executive', '2015-02-12 14:30:16', '2015-02-22 23:28:17', 3),
(113, 'operation', '2015-02-12 14:31:56', '2016-07-09 11:10:54', 2),
(114, 'executive', '2015-02-12 14:33:23', '2015-02-22 23:28:17', 3),
(115, 'operation', '2015-02-12 14:38:21', '2016-07-09 11:10:54', 2),
(116, 'operation', '2015-02-12 20:20:53', '2016-07-09 11:10:54', 2),
(117, 'executive', '2015-02-12 20:33:56', '2015-02-22 23:28:17', 3),
(118, 'operation', '2015-02-12 21:07:08', '2016-07-09 11:10:54', 2),
(119, 'operation', '2015-02-13 10:09:53', '2016-07-09 11:10:54', 2),
(120, 'admin', '2015-02-13 11:06:43', '2017-04-04 18:16:08', 1),
(121, 'executive', '2015-02-13 11:40:19', '2015-02-22 23:28:17', 3),
(122, 'admin', '2015-02-13 22:44:29', '2017-04-04 18:16:08', 1),
(123, 'admin', '2015-02-14 19:58:59', '2017-04-04 18:16:08', 1),
(124, 'admin', '2015-02-15 09:17:53', '2017-04-04 18:16:08', 1),
(125, 'operation', '2015-02-15 09:18:53', '2016-07-09 11:10:54', 2),
(126, 'executive', '2015-02-15 09:19:21', '2015-02-22 23:28:17', 3),
(127, 'admin', '2015-02-16 13:32:56', '2017-04-04 18:16:08', 1),
(128, 'admin', '2015-02-16 13:39:33', '2017-04-04 18:16:08', 1),
(129, 'admin', '2015-02-16 13:41:33', '2017-04-04 18:16:08', 1),
(130, 'admin', '2015-02-16 13:42:09', '2017-04-04 18:16:08', 1),
(131, 'admin', '2015-02-16 13:46:08', '2017-04-04 18:16:08', 1),
(132, 'admin', '2015-02-16 13:49:24', '2017-04-04 18:16:08', 1),
(133, 'executive', '2015-02-16 13:52:10', '2015-02-22 23:28:17', 3),
(134, 'operation', '2015-02-16 13:53:41', '2016-07-09 11:10:54', 2),
(135, 'admin', '2015-02-16 14:11:37', '2017-04-04 18:16:08', 1),
(136, 'admin', '2015-02-16 14:11:40', '2017-04-04 18:16:08', 1),
(137, 'admin', '2015-02-16 14:12:46', '2017-04-04 18:16:08', 1),
(138, 'operation', '2015-02-17 00:38:27', '2016-07-09 11:10:54', 2),
(139, 'executive', '2015-02-17 01:08:01', '2015-02-22 23:28:17', 3),
(140, 'acc', '2015-02-17 01:20:41', '2016-07-09 10:54:42', 4),
(141, 'admin', '2015-02-17 11:05:51', '2017-04-04 18:16:08', 1),
(142, 'admin', '2015-02-17 11:11:28', '2017-04-04 18:16:08', 1),
(143, 'admin', '2015-02-17 12:01:55', '2017-04-04 18:16:08', 1),
(144, 'admin', '2015-02-17 15:37:14', '2017-04-04 18:16:08', 1),
(145, 'admin', '2015-02-18 12:17:20', '2017-04-04 18:16:08', 1),
(146, 'executive', '2015-02-18 15:15:06', '2015-02-22 23:28:17', 3),
(147, 'admin', '2015-02-19 10:00:02', '2017-04-04 18:16:08', 1),
(148, 'operation', '2015-02-19 17:49:30', '2016-07-09 11:10:54', 2),
(149, 'executive', '2015-02-19 17:49:50', '2015-02-22 23:28:17', 3),
(150, 'operation', '2015-02-19 18:05:23', '2016-07-09 11:10:54', 2),
(151, 'acc', '2015-02-19 18:24:54', '2016-07-09 10:54:42', 4),
(152, 'executive', '2015-02-19 18:25:09', '2015-02-22 23:28:17', 3),
(153, 'finance', '2015-02-19 18:25:56', '2017-04-07 12:12:45', 5),
(154, 'acad', '2015-02-19 18:26:12', '2016-07-09 11:09:57', 6),
(155, 'admin', '2015-02-19 18:34:23', '2017-04-04 18:16:08', 1),
(156, 'admin', '2015-02-19 19:29:41', '2017-04-04 18:16:08', 1),
(157, 'admin', '2015-02-20 08:42:51', '2017-04-04 18:16:08', 1),
(158, 'acc', '2016-07-09 10:54:18', '2016-07-09 10:54:42', 4),
(159, 'admin', '2016-07-09 10:54:52', '2017-04-04 18:16:08', 1),
(160, 'finance', '2016-07-09 11:09:07', '2017-04-07 12:12:45', 5),
(161, 'acad', '2016-07-09 11:09:39', '2016-07-09 11:09:57', 6),
(162, 'operation', '2016-07-09 11:10:14', '2016-07-09 11:10:54', 2),
(163, 'executive', '2016-07-09 11:11:07', '2015-02-22 23:28:17', 3),
(164, 'acc', '2015-02-21 10:46:09', '', 4),
(165, 'admin', '2015-02-21 11:32:13', '2017-04-04 18:16:08', 1),
(166, 'operation', '2015-02-21 11:34:19', '', 2),
(167, 'executive', '2015-02-21 11:34:45', '2015-02-22 23:28:17', 3),
(168, 'admin', '2015-02-22 22:33:29', '2017-04-04 18:16:08', 1),
(169, 'executive', '2015-02-22 23:27:30', '2015-02-22 23:28:17', 3),
(170, 'admin', '2015-02-23 00:09:04', '2017-04-04 18:16:08', 1),
(171, 'admin', '2015-02-24 16:39:57', '2017-04-04 18:16:08', 1),
(172, 'admin', '2015-02-25 13:52:30', '2017-04-04 18:16:08', 1),
(173, 'admin', '2015-02-26 07:46:40', '2017-04-04 18:16:08', 1),
(174, 'admin', '2015-02-26 21:28:40', '2017-04-04 18:16:08', 1),
(175, 'admin', '2017-03-22 00:28:50', '2017-04-04 18:16:08', 1),
(176, 'admin', '2017-03-22 00:31:34', '2017-04-04 18:16:08', 1),
(177, 'admin', '2017-03-22 00:32:05', '2017-04-04 18:16:08', 1),
(178, 'admin', '2017-03-22 00:54:06', '2017-04-04 18:16:08', 1),
(179, 'admin', '2017-03-22 00:57:18', '2017-04-04 18:16:08', 1),
(180, 'admin', '2017-03-22 01:08:16', '2017-04-04 18:16:08', 1),
(181, 'admin', '2017-03-24 23:00:43', '2017-04-04 18:16:08', 1),
(182, 'admin', '2017-03-24 23:03:02', '2017-04-04 18:16:08', 1),
(183, 'admin', '2017-03-25 05:47:45', '2017-04-04 18:16:08', 1),
(184, 'admin', '2017-03-25 05:56:51', '2017-04-04 18:16:08', 1),
(185, 'admin', '2017-03-25 10:22:37', '2017-04-04 18:16:08', 1),
(186, 'admin', '2017-03-25 12:01:50', '2017-04-04 18:16:08', 1),
(187, 'admin', '2017-03-26 21:23:10', '2017-04-04 18:16:08', 1),
(188, 'admin', '2017-03-27 00:06:03', '2017-04-04 18:16:08', 1),
(189, 'admin', '2017-03-27 00:10:20', '2017-04-04 18:16:08', 1),
(190, 'admin', '2017-03-27 03:04:23', '2017-04-04 18:16:08', 1),
(191, 'admin', '2017-03-27 05:20:27', '2017-04-04 18:16:08', 1),
(192, 'admin', '2017-03-27 10:27:11', '2017-04-04 18:16:08', 1),
(193, 'admin', '2017-03-28 22:31:25', '2017-04-04 18:16:08', 1),
(194, 'admin', '2017-03-29 11:32:16', '2017-04-04 18:16:08', 1),
(195, 'admin', '2017-03-30 12:29:00', '2017-04-04 18:16:08', 1),
(196, 'admin', '2017-03-30 14:26:42', '2017-04-04 18:16:08', 1),
(197, 'admin', '2017-03-30 21:54:48', '2017-04-04 18:16:08', 1),
(198, 'admin', '2017-03-30 23:21:01', '2017-04-04 18:16:08', 1),
(199, 'admin', '2017-03-31 00:19:47', '2017-04-04 18:16:08', 1),
(200, 'admin', '2017-03-31 00:19:50', '2017-04-04 18:16:08', 1),
(201, 'admin', '2017-03-31 00:19:52', '2017-04-04 18:16:08', 1),
(202, 'admin', '2017-03-31 00:19:53', '2017-04-04 18:16:08', 1),
(203, 'admin', '2017-03-31 00:19:54', '2017-04-04 18:16:08', 1),
(204, 'admin', '2017-03-31 00:20:44', '2017-04-04 18:16:08', 1),
(205, 'admin', '2017-03-31 13:07:17', '2017-04-04 18:16:08', 1),
(206, 'admin', '2017-04-01 10:21:39', '2017-04-04 18:16:08', 1),
(207, 'admin', '2017-04-01 10:43:44', '2017-04-04 18:16:08', 1),
(208, 'admin', '2017-04-01 19:36:44', '2017-04-04 18:16:08', 1),
(209, 'admin', '2017-04-01 19:39:44', '2017-04-04 18:16:08', 1),
(210, 'admin', '2017-04-01 19:42:42', '2017-04-04 18:16:08', 1),
(211, 'admin', '2017-04-04 15:57:18', '2017-04-04 18:16:08', 1),
(212, 'admin', '2017-04-04 16:08:23', '2017-04-04 18:16:08', 1),
(213, 'admin', '2017-04-04 16:35:49', '2017-04-04 18:16:08', 1),
(214, 'admin', '2017-04-04 17:02:51', '2017-04-04 18:16:08', 1),
(215, 'admin', '2017-04-04 17:07:00', '2017-04-04 18:16:08', 1),
(216, 'admin', '2017-04-04 17:50:52', '2017-04-04 18:16:08', 1),
(217, 'admin', '2017-04-04 18:00:22', '2017-04-04 18:16:08', 1),
(218, 'Kagoya', '2017-04-04 18:39:10', '', 8),
(219, 'Kagoya', '2017-04-04 18:39:41', '', 8),
(220, 'Castro', '2017-04-04 18:39:49', '', 4),
(221, 'Castro', '2017-04-04 18:40:24', '', 4),
(222, 'Castro', '2017-04-04 18:47:22', '', 4),
(223, 'abi', '2017-04-04 18:48:04', '', 11),
(224, 'Kagoya', '2017-04-04 18:48:35', '', 8),
(225, 'Kagoya', '2017-04-04 18:51:50', '', 8),
(226, 'Kagoya', '2017-04-04 18:56:17', '', 8),
(227, 'abi', '2017-04-04 19:00:34', '', 11),
(228, 'Kagoya', '2017-04-04 19:00:43', '', 8),
(229, 'kagoya', '2017-04-06 11:56:30', '', 8),
(230, 'kiggundu', '2017-04-06 12:02:36', '', 23),
(231, 'kagoya', '2017-04-06 12:32:33', '', 8),
(232, 'kagoya', '2017-04-06 15:37:45', '', 8),
(233, 'kagoya', '2017-04-06 21:09:13', '', 8),
(234, 'alikiriza', '2017-04-06 22:37:39', '', 32),
(235, 'kagoya', '2017-04-06 22:53:25', '', 8),
(236, 'kagoya', '2017-04-06 23:11:41', '', 8),
(237, 'kagoya', '2017-04-07 09:49:46', '', 8),
(238, 'byarugaba', '2017-04-07 09:55:45', '', 33),
(239, 'kagoya', '2017-04-07 10:03:52', '', 8),
(240, 'byarugaba', '2017-04-07 11:45:54', '', 33),
(241, 'kagoya', '2017-04-07 11:58:44', '', 8),
(242, 'byarugaba', '2017-04-07 12:12:58', '', 33),
(243, 'kagoya', '2017-04-07 12:22:45', '', 8),
(244, 'kagoya', '2017-04-08 10:17:43', '', 8),
(245, 'byarugaba', '2017-04-08 23:20:57', '', 33),
(246, 'kagoya', '2017-04-08 23:32:28', '', 8),
(247, 'kagoya', '2017-04-09 00:24:41', '', 8),
(248, 'Castro', '2017-04-12 19:01:10', '', 4),
(249, 'Kagoya', '2017-04-12 19:03:27', '', 8),
(250, 'Kagoya', '2017-04-12 20:00:21', '', 8),
(251, 'Kagoya', '2017-04-15 18:21:21', '', 8),
(252, 'Kagoya', '2017-04-15 18:45:49', '', 8),
(253, 'kiggundu', '2017-04-16 10:04:10', '', 23),
(254, 'Kagoya', '2017-04-16 10:17:48', '', 8),
(255, 'Kifulugunyu', '2017-04-16 10:22:04', '', 27),
(256, 'kagoya', '2017-04-21 14:16:00', '', 8),
(257, 'kagoya', '2017-04-21 14:24:02', '', 8),
(258, 'kiggundu', '2017-04-21 15:15:05', '', 23),
(259, 'kagoya', '2017-04-22 11:39:00', '', 8),
(260, 'kagoya', '2017-04-22 11:46:28', '', 8),
(261, 'katushabe', '2017-04-22 11:46:50', '', 35),
(262, 'kagoya', '2017-04-22 11:48:23', '', 8),
(263, 'katushabe', '2017-04-22 11:49:51', '', 35),
(264, 'kagoya', '2017-04-22 11:50:47', '', 8),
(265, 'kagoya', '2017-04-29 12:24:18', '', 8),
(266, 'kagoya', '2017-04-29 13:45:15', '', 8),
(267, 'Namugabo', '2017-04-29 14:14:49', '', 36),
(268, 'kagoya', '2017-04-29 14:15:48', '', 8),
(269, 'kagoya', '2017-05-17 10:30:10', '', 8),
(270, 'katushabe', '2017-05-17 10:45:09', '', 35),
(271, 'kagoya', '2017-05-17 11:20:40', '', 8),
(272, 'kagoya', '2017-05-17 13:26:36', '', 8),
(273, 'kagoya', '2017-05-19 17:48:44', '', 8),
(274, 'namugabo', '2017-05-19 18:11:24', '', 36),
(275, 'kagoya', '2017-05-19 19:38:08', '', 8),
(276, 'namugabo', '2017-05-19 19:59:19', '', 36),
(277, 'katushabe', '2017-05-19 20:26:23', '', 35),
(278, 'kagoya', '2017-05-19 20:32:28', '', 8),
(279, 'kagoya', '2017-05-21 23:09:01', '', 8),
(280, 'kagoya', '2017-05-22 08:50:46', '', 8),
(281, 'kagoya', '2017-05-22 08:58:28', '', 8),
(282, 'kagoya', '2017-05-22 09:14:38', '', 8),
(283, 'kagoya', '2017-05-22 10:33:02', '', 8),
(284, 'kagoya', '2017-05-22 10:34:05', '', 8),
(285, 'kagoya', '2017-05-22 10:42:55', '', 8),
(286, 'kagoya', '2017-06-05 22:34:01', '', 8);
