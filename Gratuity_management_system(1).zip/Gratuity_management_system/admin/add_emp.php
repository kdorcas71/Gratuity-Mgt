<?php 
	include ('menu.php');
?>
<!-- PIKADAY CALENDAR CODE STARTS HERE-->
<link rel="stylesheet" href="pikaday/css/pikaday.css">
<script src="pikaday/js/moment.js"></script>
<!-- First load pikaday.js and then its jQuery plugin -->
<script src="pikaday/js/pikaday.js"></script>

<link rel="shortcut icon" href="../hrlogo.png">
<div class="container-fluid">

			<div class="row">
				<div class="col-md-12">
					<div class="page-header">
						<h1>Add Employee</h1>
					</div>
				</div>
			</div>
<div class="container-fluid">
	<div class = "row">
		<div class="panel panel-default">
			<div class="panel-body">
					<form enctype="multipart/form-data" method="post" class="form-horizontal">
						<fieldset>
							<div class = "col-md-9 col-md-offset-2">
								<h3>Employee Information</h3>
							</div>
							
							<!-- Text input-->
							<div class="form-group">
								<label class="col-md-2 control-label" for="id_emp">Employee ID</label>
							  <div class="col-md-2">
							  <input id="id_emp" name="id_emp" type="text" placeholder="Employee ID" class="form-control input-md">
							  </div>
							
							</div>

							<!-- Text input-->
							<div class="form-group" >
							  <label class="col-md-2 control-label" for="emp_fname">Full Name</label>  
							  <div class="col-md-3">
							  <input id="emp_fname" name="emp_fname" type="text" placeholder="First Name" class="form-control input-md" required="" pattern="[A-Za-z]{1-20}" title="It should contain only characters">
							  </div>
								<label class="col-md- control-label" for="emp_mname"></label>  
							  <div class="col-md-3">
							  <input id="emp_mname" name="emp_mname" type="text" placeholder="Middle Name" class="form-control input-md" required=""pattern="[A-Za-z]{1-20}" title="It should contain only characters">
							  </div>
								<label class="col-md- control-label" for="emp_lname"></label>
							  <div class="col-md-3">
								<input id="emp_lname" name="emp_lname" type="text" placeholder="Last Name" class="form-control input-md" required=""pattern="[A-Za-z]{1-20}" title="It should contain only characters">
							  </div>
							</div>

							<!-- Select Basic -->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="month"> Date of Birth </label>
							  
							  
							  <div class="col-md-2">
							  <input type="text" name="dateofbirth" id="dateofbirth" class="form-control"/>
							  
							
							  </div>
							
							  <div class="col-md-1">
								
							  </div>
							
							  <div class="col-md-2">
								
							  </div>
							</div>

							<!-- Text input-->
							<div class="form-group">
							  
							  
							  <label class="col-md-2 control-label" for="gen">Gender</label>
							  <div class="col-md-2">
								<select id="emp_gen" name="emp_gen" class="form-control">
								  <option>Gender</option>
								  <option>Female</option>
								  <option>Male</option>
								</select>
							  </div>
							</div>

							<!-- Textarea -->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="emp_add">Address</label>
							  <div class="col-md-4">                     
								<textarea class="form-control" id="emp_add" name="emp_add" placeholder="Address"></textarea>
							  </div>
							</div>

							<!-- Text input-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="emp_cont">Contact Number</label>  
							  <div class="col-md-4">
							  <input id="emp_cont" name="emp_cont" type="text" placeholder="Contact Number" class="form-control input-md" required="" pattern="[0-9]{10,15}" title="It should contain only Numbers">
								
							  </div>
							</div>
							<div class = "col-md-10 col-md-offset-2">
								<h3>Additional Information</h3>
							</div>
							<div class="form-group">
							  <label class="col-md-2 control-label" for="nssf">NSSF Number</label>  
							  <div class="col-md-3">
							  <input id="nssf" name="nssf" type="text" placeholder="NSSF Number" class="form-control input-md" required="" pattern="[0-9]{10,15}" title="It should contain only Numbers">
								
							  </div>
							
							
							
							  <label class="col-md-2 control-label" for="TIN">TIN Number</label>  
							  <div class="col-md-3">
							  <input id="tin" name="tin" type="text" placeholder="TIN Number" class="form-control input-md" required="" pattern="[0-9]{10,15}" title="It should contain only Numbers" min="0">
								
							  </div>
							</div>
							
							<div class = "col-md-10 col-md-offset-2">
								<h3>Employee Status</h3>
							</div>
							
							<div class="form-group">
							  <label class="col-md-2 control-label" for="email">Email Address</label>  
							  <div class="col-md-4">
							  <input id="email" name="email" type="text" placeholder="Email Address" class="form-control input-md" required="">
								
							  </div>
							  <div class="col-md-2">
								   <?php
									   $select = "SELECT * FROM sal_scale";
									   $qry = mysql_query($select);
									   
									   echo "<select id='id_scale' name='id_scale' class='form-control'>";
									   echo "<option>Salary Scale</option>";
									   while($rec = mysql_fetch_array($qry)){
										  echo"<option value = '$rec[id_scale]'>$rec[sal_scale]</option>";
									   }
										echo"</select>";
									?>
							  </div>
							 
							</div>
							
							<!-- Select Basic -->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="emp_stat">Status</label>
							  <div class="col-md-2">
								<select id="emp_stat" name="emp_stat" class="form-control">
								   <option>--select status--</option>
								  <option value="Single">Single</option>
								  <option value="Married">Married</option>
								  <option value="Widow">Widow</option>
								  <option value="Widower">Widower</option>
								</select>
							  </div>
							  
							  <div class="col-md-2">
							    <p>
							      <select id="emp_pos" name="emp_pos" class="form-control">
							        <option>--select position--</option>
							        <option value="Administrative">Administrative</option>
							        <option value="Teaching Personnel">Teaching Personnel</option>
							        <option value="Secretary">Secretary</option>
							        <option value="Non Teaching Staff">Non Teaching Staff</option>
                                    <option value="Human Resource">Human Resource</option>
                                    
						          </select>
						        </p>
							    <p>&nbsp;  </p>
							  </div>
							  
							  <div class="col-md-2">
								   <?php
									   $select = "SELECT * FROM ldays";
									   $qry = mysql_query($select);
									   
									   echo "<select id='id_pos' name='id_pos' class='form-control'>";
									   echo "<option>--select contract type--</option>";
									   while($recs = mysql_fetch_array($qry)){
										  echo"<option value = '$recs[id_pos]'>$recs[pos_stat]</option>";
									   }
										echo"</select>";
									?>
							  </div>
							  
							   <div class="col-md-2">
								   <?php
									   $select = "SELECT * FROM department";
									   $qry = mysql_query($select);
									   
									   echo "<select id='id_dept' name='id_dept' class='form-control'>";
									   echo "<option>--select department--</option>";
									   while($rec = mysql_fetch_array($qry)){
										  echo"<option value = '$rec[id_dept]'>$rec[depart_name]</option>";
									   }
										echo"</select>";
									?>
							  </div>
							</div>
							<div class="form-group">
							  <label class="col-md-2 control-label" for="month">Start Date</label>
							  <div class="col-md-2">
							  
							   <input type="text" name="startdate" id="startdate" class="form-control"/>
							  
								
							  </div>
							
							  <div class="col-md-1">
								
							  </div>
							
							  <div class="col-md-2">
								
							  </div>

							<!-- Text input-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="addedby">Added By</label>  
							  <div class="col-md-3">
							  <input id="addedby" name="addedby" type="text" class="form-control input-md" value="<?php echo " ".$FirstName." ".$LastName." ";?>" readonly>
								
							  </div>
							</div>

							<!-- Button (Double) -->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="submit"></label>
							  <div class="col-md-8">
								<button id="submit" name="submit" class="btn btn-primary">Submit</button>
								<a href = "emp_list.php"><input type = "button" value = "Cancel" class="btn btn-default"></a>
							  </div>
							</div>

						</fieldset>
					</form>
			</div>
		</div>
	</div>
</div>

		</div>	<!--close div of container-->
        
        <?php	
	if (isset($_POST['submit']))
	
		if (($_POST['emp_fname'] == '')or($_POST['emp_lname'] == '')or($_POST['emp_mname'] == '')or($_POST['dateofbirth'] == '')
		or($_POST['emp_gen'] == '')or($_POST['emp_add'] == '')
		or($_POST['emp_cont'] == '')or($_POST['nssf'] == '')or($_POST['tin'] == '')
		or($_POST['year3'] == '') or($_POST['month3'] == '')or($_POST['day3'] == '')or($_POST['id_scale'] == '')
		or($_POST['email'] == '')or($_POST['emp_stat'] == '')or($_POST['emp_pos'] == '')or($_POST['id_pos'] == '')or($_POST['addedby'] == ''))
		{
			echo "You must fill those fields";
		}	
	else{ //dri namn is ang mga "name=stu_id" nga ara sa mga input type. 
		$a = addslashes("$_POST[id_emp]");
		$b = addslashes("$_POST[emp_fname]");
		$c = addslashes("$_POST[emp_lname]");
		$d = addslashes("$_POST[emp_mname]");
		$e = addslashes("$_POST[dateofbirth]");
		//$f = addslashes("$_POST[emp_age]");
		$g = addslashes("$_POST[emp_gen]");
		$h = addslashes("$_POST[emp_add]");
		$j = addslashes("$_POST[emp_cont]");
		$q = addslashes("$_POST[nssf]");
		$o = addslashes("$_POST[tin]");
		$u = addslashes("$_POST[email]");
		$q = addslashes("$_POST[id_scale]");
		$i = addslashes("$_POST[emp_stat]");
		$k = addslashes("$_POST[emp_pos]");	
		$n = addslashes("$_POST[id_dept]");
		$m = addslashes("$_POST[id_pos]");
		$p = addslashes("$_POST[startdate]");
		$l = addslashes("$_POST[addedby]");
		$dat = strtotime("now");
		$da = date("Y-m-d",$dat);
		
		//insert into database
		$sql = "INSERT INTO employee
					(`emp_id`,`id_emp`,`emp_fname`,`emp_lname`,`emp_mname`,`emp_bday`,`emp_gen`,`emp_add`,`emp_cont`,`nssf`,`tin`,`email`,`emp_stat`,`emp_pos`,`id_dept`,`id_pos`,`addedby`,`emp_date`,`emp_start`,`id_scale`,`stat`)
						values('','$a','$b','$c','$d','$e','$g','$h','$j','$q','$o','$u','$i','$k','$n','$m','$l','$da','$p','$q','1')";
		$qry = mysql_query($sql);
			if ($qry){
				echo '<div style="position:absolute; left:450px; top:200px; width: 450px">
								<div class="alert alert-success">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">
										×</button>
								   <span class="glyphicon glyphicon-ok"></span> <strong>Done!</strong>
									<hr class="message-inner-separator">
									<p><strong>Success!</strong> Employee Information added!
									&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
									<a href="emp_list.php"><button type="button" class="btn btn-success">Continue</button></a>
									</p>
								</div>
							</div>';
					exit();
				}
			else {
				echo "not posted!";
				}
		}
	
?>

	<?php include('footer.php');?>
	
	<script>
	var startdate = new Pikaday(
    {
	     format: 'YYYY-MM-DD',
        field: document.getElementById('startdate'),
		maxDate: new Date(),
	
		
        
    });
	
	
	var dateofbirth = new Pikaday(
    {
	     format: 'YYYY-MM-DD',
        field: document.getElementById('dateofbirth'),
		maxDate: moment().subtract(18, 'years').toDate(),
	
		
        
    });
	
</script>