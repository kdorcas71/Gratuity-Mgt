
<?php 
	include ('menu.php');
	
	$id_emp = $_GET['id_emp'];
?>













<?php	
			
			
			//$length_service = $_GET['length_service'];
	if (isset($_POST['submit']))
	{
		
		if (($_POST['id_emp'] == '')or($_POST['length_service'] == '')or($_POST['basic_pay'] == '')or ($_POST['sal_scale'] == '')
		or($_POST['gratiuty'] == '') or($_POST['submitedby'] == ''))
		{
		
			echo "You must fill those fields";
		}	
	else
	{ 
		
			$a = addslashes("$_POST[id_emp]");
		$email = addslashes("$_POST[email]");
		$fname = addslashes("$_POST[firstname]");
		$b = addslashes("$_POST[length_service]");
		$c = addslashes("$_POST[basic_pay]");
		$d = addslashes("$_POST[sal_scale]");
		$e = addslashes("$_POST[gratiuty]");
	    $g = addslashes("$_POST[submitedby]");
		
		$datecreated=date("Y-m-d h:i:s");


$result=mysql_query("select * from gratuity where id_emp='$a' ")or die (mysql_error());//database query
	$count=mysql_num_rows($result);
			
		
			if ($count > 0)
			{
			
			
$st="You have already calculated Gratuity for this employee. You can not calculate it twice";
  ?>
  
  <div class="alert alert-success" align="center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php  echo $st; ?>
</div>
			
		<?php
		    }
			else
			{
		
		//code for sending an acknowledgement email to the employee
require('phpmailer/class.phpmailer.php');

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->Username = 'dkagoya171@gmail.com';
$mail->Password = 'ndikwani71';

	$mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only

	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail

	$mail->Port = 465; 

$mail->From="dkagoya171@gmail.com";
$mail->FromName="GRATUITY MIS";
$mail->Sender="dkagoya171@gmail.com";
$mail->AddReplyTo("dkagoya171@gmail.com", "GRATUITY CALCULATION");

if($email !=" ")
{

$mail->AddAddress($email);
$emailaddresses= $email ;
}

$mail->Subject = "GRATUITY CALCULATION";
$mail->IsHTML(false);

$mail->Body = "Dear"." ".$fname."".".thank you for the services rendered to the Institution. Your Gratuity for the period of"."  ".$b." ". "months served is"." ".$e." "."

It will be deposited soon on your bank account";

$mail->WordWrap   = 65; // set word wrap

if(!$mail->Send()) 
{
  echo "Mailer Error: " . $mail->ErrorInfo;
} 
else {
  
   $stt="Gratuity alert has been sent to the employee";
  ?>
  
  <div class="alert alert-success" align="center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php  echo $stt; ?>
</div>
<?php
//closing bracket for sending the email alert
				}
		
	
		//insert into database
		$sql = "INSERT INTO gratuity
					(id_emp,length_service,basic_pay,sal_scale,totalgratuity,date_calculated,submitedby)
						values('$a','$b','$c','$d','$e','$datecreated','$g')";
		$qry = mysql_query($sql)or die("Query not effective:".mysql_error());
			if ($qry)
			{
				echo '<div style="position:absolute; left:450px; top:200px; width: 450px">
								<div class="alert alert-success">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">
										�</button>
								   <span class="glyphicon glyphicon-ok"></span> <strong>Done!</strong>
									<hr class="message-inner-separator">
									<p><strong>Success!</strong>Gratiuty successfully recorded!
									&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
									<a href="notif_list.php"><button type="button" class="btn btn-success">Continue</button></a>
									</p>
								</div>
							</div>';
							
							 
					exit();
					
				}
		else 
		{
				echo "not posted!";
				}
				
				//closing to validate if the gratuity of the employee has not been calculated before
				}
				
				//closing the validation
				}
				//closing the submit event
				}
		
?>
<link rel="shortcut icon" href="../hrlogo.png">
	<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="page-header">
							<h1>Gratuity Calculator</h1>
					</div>
				</div>
			</div>
			
				
<div class="container-fluid">
	<div class = "row">
		<div class="panel panel-default">
			<div class="panel-body">
						<div class = "col-md-4 col-md-offset-2">
							<h3>Employee Information</h3>
						</div>
		<div class="row">
			<div class="col-md-11 col-md-offset-1">
				<form  method="post" class="form-horizontal">
				 <?php
							  $sql = "SELECT notification.id_emp, notification.start_date,notification.end_date,notification.length_service, notification.comment1,notification.comment2,notification.comment3,employee.id_emp,employee.emp_fname,employee.emp_lname,employee.emp_mname,employee.email
				
						FROM notification INNER JOIN employee ON employee.id_emp=notification.id_emp  where notification.id_emp='$id_emp'";
		$qry = mysql_query($sql);
	if($rec=mysql_fetch_array($qry))
						{
						$employeeID=$rec['id_emp'];
						$fname=$rec['emp_fname'];
						$yearsserved=$rec['length_service'];
						$email=$rec['email'];
						?>
				<div class="form-group">
								<label class="col-md-2 control-label" for="id_emp">Employee ID</label>
							  <div class="col-md-2">
							 
							  <input id="id_emp" name="id_emp" type="text" class="form-control input-md" value="<?php echo $employeeID;?>" readonly>
                              <input id="email" name="email" type="hidden" class="form-control input-md" value="<?php echo $email;?>" readonly>
                              <input id="firstname" name="firstname" type="hidden" class="form-control input-md" value="<?php echo $fname;?>" readonly>
							
							  </div>
							
				  </div>

							
				  <!-- Text input-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="length_service">Length of Service</label>  
							  <div class="col-md-3">
							
								<input id="length_service" name="length_service" type="text" class="form-control input-md" value="<?php echo " ".$yearsserved." ";?>" readonly>
							  </div>
							</div>

							<!-- Select Basic -->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="basic_pay">Basic Pay</label>
								<div class="col-md-3">
								  <?php
					
					$sql = "select id_scale from employee where id_emp='$id_emp'";
								$result=mysql_query($sql);
		                       
							   if($rec=mysql_fetch_array($result))
						{
						
						$id_scale1 = $rec['id_scale'];
						//echo $id_scale1;
						$sql1 = "select basic_pay from basic_pay where id_basic=$id_scale1";
						//echo $sql1;
						$result1=mysql_query($sql1);
						if($rec1=mysql_fetch_array($result1))
						{
						
						 $basicpay=$rec1['basic_pay'];
						 
						?>
								<input id="basic_pay" name="basic_pay" type="text" class="form-control input-md" value="<?php  echo $basicpay; ?> " readonly>
								
								<?php
								
								}
						}
						
						
						?>
							</div>
							<div class="form-group">
								<label class="col-md-2 control-label" for="sal_scale">Salary Scale</label>
							  <div class="col-md-2">
			<?php
							  
								// getBasicPay($id_emp);
								$sql = "select id_scale from employee where id_emp='$id_emp'";
								$result=mysql_query($sql);
		                       
							   if($rec=mysql_fetch_array($result))
						{
						
						
							   ?>
										  
										
							  <input id="sal_scale" name="sal_scale" type="text" class="form-control input-md" value="<?php echo $rec['id_scale'];?>" readonly>
							  
							  <?php
							}
							  ?>
							
							  </div>
                              </div>
                             						
							 
							
							 
                            
							<?php
							
							$sql2 = "select id_scale from employee where id_emp='$id_emp'";
								$result2=mysql_query($sql2);
		                       
							   if($rec=mysql_fetch_array($result2))
						{
						
						$id_scale2 = $rec['id_scale'];
							
							$sql2 = "select basic_pay from basic_pay where id_basic='$id_scale2'";
						//echo $sql1;
						$result2=mysql_query($sql2);
						if($rec2=mysql_fetch_assoc($result2))
						{
						
						 $basicpay1=$rec2['basic_pay'];
						 
						 //calculating monthly gratuity
							  $mgratiuty=(10/100)*$basicpay1;
							  
							  //Calculating gratuity for the months serviced
							  
			  				  $gratiuty=$mgratiuty*$yearsserved;
					
								
								
						
							
							  
						
							   ?>
                              <!-- outting Monthly Gratuity-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="addedby">Monthly Gratuity</label>  
							  <div class="col-md-2">
							  <input id="mgratiuty" name="mgratiuty" type="text" class="form-control input-md" value="<?php echo $mgratiuty;?>" readonly>
								
							  </div>
							</div>
                            
                             <!-- outting Gratuity for all the years served-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="addedby">Gratuity for all the years served</label>  
							  <div class="col-md-2">
							 <input id="gratiuty" name="gratiuty" type="text" class="form-control input-md" value="<?php echo $gratiuty;?>" readonly>
								
							  </div>
							</div>
                            <?php 
							} 
							
							}
							
							 ?>
                            
                            <br />
                          

                             <!-- Text input-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="addedby"> </label>  
							  <div class="col-md-2">
							  <input id="submitedby" name="submitedby" type="hidden" class="form-control input-md" value="<?php echo $id;?>" readonly>
								
							  </div>
							</div>
                            
                            
                            
                             <!-- Button (Double) -->
							<div class="form-group">
							  <label class="col-md-3 control-label" for="submit"></label>
							  <div class="col-md-4">
								<button id="submit" name="submit" class="btn btn-primary">Submit</button>
								<a href = "index.php"><input type = "button" value = "Cancel" class="btn btn-default"></a>
								</fieldset>
				
							  </div>
							</div>
							
								<?php 
	
				
				}
				?>
					</form>
							  </div>
							</div>
	<div class="container-fluid">
		<div class = "col-md-12">
			<div style="margin-top:100px;" class="text-center">
				
			</div>
		</div>
	</div>
							  
							
		
