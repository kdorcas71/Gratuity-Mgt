<!-- PIKADAY CALENDAR CODE STARTS HERE-->
<link rel="stylesheet" href="pikaday/css/pikaday.css">
<script src="pikaday/js/moment.js"></script>
<!-- First load pikaday.js and then its jQuery plugin -->
<script src="pikaday/js/pikaday.js"></script>
<link rel="shortcut icon" href="../hrlogo.png">
<link rel="stylesheet" type="text/css" href="pop.css">
		<div class="container-fluid">
			<div class="row">
				<?php include ('menu.php'); ?>
			</div>
		</div>
<div class="container-fluid">
        <?php	

	if (isset($_POST['submit'])){
		
		if (($_POST['id_emp'] == '')or($_POST['emp_fname'] == '')or($_POST['emp_mname'] == '')or ($_POST['emp_lname'] == '')
		or($_POST['email'] == '')
		or($_POST['reason'] == '')or($_POST['enddate'] == '')or($_POST['sentby'] == ''))
		{
		
			echo "You must fill those fields";
		}	
	else{ 
		
		$a = addslashes("$_POST[id_emp]");
		$b = addslashes("$_POST[emp_fname]");
		$c = addslashes("$_POST[emp_lname]");
		$d = addslashes("$_POST[emp_mname]");
		$e = addslashes("$_POST[email]");
		$f = addslashes("$_POST[reason]");
		$h = addslashes("$_POST[enddate]");
		$g = addslashes("$_POST[sentby]");
		

//code for sending an acknowledgement email to the employee
require('phpmailer/class.phpmailer.php');

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->Username = 'dkagoya171@gmail.com';
$mail->Password = 'ndikwani71';

	$mail->SMTPDebug = 1;  // debugging: 1 = errors and messages, 2 = messages only

	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail

	$mail->Port = 465; 

$mail->From="dkagoya171@gmail.com";
$mail->FromName="GRATUITY MIS";
$mail->Sender="dkagoya171@gmail.com";
$mail->AddReplyTo("dkagoya171@gmail.com", "CONTRACT TERMINATION NOTIFICATION");

if($email !=" ")
{

$mail->AddAddress($email);
$emailaddresses= $email ;
}

$mail->Subject = "CONTRACT TERMINATION NOTIFICATION";
$mail->IsHTML(false);

$mail->Body = "Dear"." ".$b."".".thank you for the services rendered to the Institution. However this is to notify you that your contract with the institution will terminated effective"." " .$h." ". "from now because of"." ".$f ;

$mail->WordWrap   = 65; // set word wrap

if(!$mail->Send()) 
{
  echo "Mailer Error: " . $mail->ErrorInfo;
} 
else {
  
   $stt="Alert has been sent to the employee";
  ?>
  
  <div class="alert alert-success" align="center">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php  echo $stt; ?>
</div>
<?php
//closing bracket for sending the email alert
				}

		$datecreated=date("Y-m-d h:i:s");
		
		//insert into database
		$sql = "INSERT INTO alert
					(id_emp,reason,enddate,sentby,datecreated)
						values('$a','$f','$h','$g','$datecreated')";
					
		$qry = mysql_query($sql)or die("Un able to insert alert".mysql_error());
			if ($qry){
				echo '<div style="position:absolute; left:450px; top:200px; width: 450px">
								<div class="alert alert-success">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">
										�</button>
								   <span class="glyphicon glyphicon-ok"></span> <strong>Done!</strong>
									<hr class="message-inner-separator">
									<p><strong>Success!</strong> Notification successfully sent!
									&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
									<a href="emp_list.php"><button type="button" class="btn btn-success">Continue</button></a>
									</p>
								</div>
							</div>';
							
							 
					exit();
				
					
				}
			else {
				echo "Record not stored!";
				}
		}
	}
?>



<?php
					$select = "SELECT * FROM dbhr.employee, dbhr.department, dbhr.ldays WHERE
								employee.id_dept = department.id_dept 
								AND ldays.id_pos = employee.id_pos 
								AND employee.
								emp_id='$_GET[id]'";
					
					$qry=mysql_query($select);
					$rec = mysql_fetch_array($qry);
								$id = "$rec[id_emp]";
								$fname = "$rec[emp_fname]";
								$lname = "$rec[emp_lname]";
								$mname = "$rec[emp_mname]";
								$email = "$rec[email]";
								
				?>

	<div class="row" style="margin-top:20px">
		<div class="col-xs-9 col-md-offset-3">
			<div class="row">
				<div class="col-md-12">
					<div class="page-header">
						<h1>HUMAN RESOURCE ALERT</h1>
					</div>
				</div>
			</div>
<div class="container-fluid">
	<div class = "row">
		<div class="panel panel-default">
			<div class="panel-body">
					<form  method="post" class="form-horizontal">
					
						<fieldset>
							<div class = "col-md-9 col-md-offset-2">
								<h3>ALERT</h3>
							</div>
							
							<!-- Text input-->
							<div class="form-group">
							
								<label class="col-md-2 control-label" for="id_emp">Employee ID</label>
							  <div class="col-md-2">
							  <input id="id_emp" name="id_emp" type="text" class="form-control input-md" value="<?php echo $rec['id_emp']?>" readonly>
							
							  </div>
							
							</div>

							<!-- Text input-->
							<div class="form-group" >
							  <label class="col-md-2 control-label" for="emp_fname">Full Name</label>  
							  <div class="col-md-2">
							  <input id="emp_fname" name="emp_fname" type="text" class="form-control input-md" value="<?php echo $rec['emp_fname']?>" readonly>
							  </div>
								<label class="col-md- control-label" for="emp_mname"> </label>  
							  <div class="col-md-2">
							  <input id="emp_mname" name="emp_mname" type="text" class="form-control input-md" value="<?php echo $rec['emp_mname']?>" readonly>
							  </div>
								<label class="col-md- control-label" for="emp_lname"></label>
							  <div class="col-md-2">
								<input id="emp_lname" name="emp_lname" type="text" class="form-control input-md" value="<?php echo $rec['emp_lname']?>" readonly>
							  </div>
							  </div>
				
							<div class="form-group">
								<label class="col-md-2 control-label" for="email">Email Address</label>
							  <div class="col-md-7">
							  <input id="email" name="email" type="text" class="form-control input-md" value="<?php echo $rec['email']?>" readonly>
							
							  </div>
							
							</div>
								
							<div class="form-group">
							  <label class="col-md-1 control-label" for="reason">Reason.</label>
							  <div class="col-md-5">                     
								<textarea class="form-control" id="reason" name="reason" placeholder="Reason"></textarea>
							  </div>
							</div>
							<div class="form-group">
								<label class="col-md-2 control-label" for="email">End Date</label>
							  <div class="col-md-2">
							  <input type="text" name="enddate" id="enddate" class="form-control"/>
							
							  </div>
							
							  
							 
							  <!-- Text input-->
							<div class="form-group">
							  <label class="col-md-2 control-label" for="sumitedby">Sent By.</label>  
							  <div class="col-md-3">
							  <input id="sentby" name="sentby" type="text" class="form-control input-md" value="<?php echo " ".$FirstName." ".$LastName." ";?>" readonly>
								
							  </div>
							</div>

							  <!-- Button (Double) -->
							<div class="form-group">
							  <label class="col-md-3 control-label" for="submit"></label>
							  <div class="col-md-4">
								<button id="submit" name="submit" class="btn btn-primary">Submit</button>
								<a href = "index.php"><input type = "button" value = "Cancel" class="btn btn-default"></a>
								</fieldset>
					</form>
							  </div>
							</div>
	<div class="container-fluid">
		<div class = "col-md-12">
			<div style="margin-top:100px;" class="text-center">
				
			</div>
		</div>

	
		<?php include ('footer.php'); 
		
		?>
<script>
	var enddate = new Pikaday(
    {
	     format: 'YYYY-MM-DD',
        field: document.getElementById('enddate'),
		minDate: new Date(),
	
		
        
    });
	
	
	
	
</script>
