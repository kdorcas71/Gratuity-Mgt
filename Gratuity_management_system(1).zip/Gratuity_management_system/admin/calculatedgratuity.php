<?php 
	include ('menu.php');
?>
<link rel="shortcut icon" href="../hrlogo.png">
<div class="container-fluid">
				<div class = "row" style ="margin-top:50px">	
					<div class = "col-md-4">
						<ul class="nav nav-tabs">
													
						</ul>
					</div>
					<div class ="col-md-4">
						<h1>GRATUITY CALCULATED  </h1>
					</div>
				</div>
	<div class="col-md-12">
			<div class = "col-md-10">
<?php
						error_reporting(E_ALL & ~E_NOTICE);
						//paging codes
						if (isset($_GET["page"])) 
											{ 
												$page = $_GET["page"]; 
											} else { 
												$page=1; 
											};
											$endlimit = 10; 
											$start_from = ($page-1) * $endlimit;
						//this will get the data in database		
						$welcome_view = 'SELECT DISTINCT gratuity.emp_id,gratuity.id_emp,gratuity.length_service,gratuity.sal_scale,gratuity.basic_pay,gratuity.totalgratuity
						,gratuity.date_calculated,gratuity.submitedby,
						employee.id_emp,employee.emp_fname,employee.emp_lname,employee.emp_mname,employee.email
				
						FROM  gratuity LEFT OUTER JOIN employee  ON employee.id_emp=gratuity.id_emp';
												
						
						$welcome_viewed = mysql_query($welcome_view);
						
											?>
			</div>
		<div class="col-md-2">
	
		</div>
	</div>
<div class="container-fluid" style="margin-top:80px;">
	<div class = "row">
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="table-responsive">
					<?php
						$sql="SELECT DISTINCT gratuity.emp_id,gratuity.id_emp,gratuity.length_service,gratuity.sal_scale,gratuity.basic_pay,gratuity.totalgratuity
						,gratuity.date_calculated,gratuity.submitedby,
						employee.id_emp,employee.emp_fname,employee.emp_lname,employee.emp_mname,employee.email
				
					FROM  gratuity LEFT OUTER JOIN employee  ON employee.id_emp=gratuity.id_emp";
						$qry=mysql_query($sql);
					?>

					<table class="table table-hover">
						<thead>
							<tr>
							    <th>Employee ID</th>
                                <th>First Name</th>
								<th>Last Name</th>
								<th>Email</th>
								<th>Length of service (Months)</th>
                                <th>Gratuity</th>
                                <th>Date Calculated</th>
                                
								
							</tr>
						</thead>
						<?php
						while($rec=mysql_fetch_array($qry))
						{
						?>
						<tbody>
							<tr>
									<td>
                                           
	    							<?php echo $rec['id_emp'] ?>
									</td>
									<td>
										<?php echo $rec['emp_fname'] ?>
									</td>
									<td>
										<?php echo $rec['emp_lname'] ?>
									</td>
									<td>
										<?php echo $rec['email'] ?>
									</td>
									<td>
										<?php echo $rec['length_service'] ?>
									</td>
                                    <td>
										<?php echo $rec['totalgratuity'] ?>
									</td>
                                    <td>
										<?php echo $rec['date_calculated'] ?>
									</td>
									
							
					<?php
						}
					?>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
		//paging codes "$welcome_viewed halin ni sa ging query sang $welcome_view"
		$num_rows = mysql_num_rows($welcome_viewed);
		$total_pages = ceil($num_rows / $endlimit);
		$i=0;
		echo ' '.$_REQUEST["page"].' ';
				for($i=1; $i<=$total_pages; $i++ )
					{
						 echo"<ul class='pagination '> <li>&nbsp<a href = 'notif_list.php?page=".$i."'>".$i."</a></li></ul>";
					}
						echo'&nbsp&nbsp';
?>
</div>
<script>
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>
	<?php include('footer.php'); ?>
